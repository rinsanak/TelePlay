package com.telegramtv.audio

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/**
 * Runtime PCM gain for playback-only volume boosting.
 *
 * This does not modify or re-encode the source file. 100% is unity gain;
 * values above 100% amplify decoded PCM before it reaches the audio sink.
 */
@OptIn(UnstableApi::class)
class GainAudioProcessor : BaseAudioProcessor() {

    @Volatile
    private var gainPercent: Int = 100

    @Volatile
    private var gainScale: Float = 1f

    fun setGainPercent(percent: Int) {
        val clamped = percent.coerceIn(100, 300)
        gainPercent = clamped
        gainScale = percentToLinearScale(clamped)
    }

    fun getGainPercent(): Int = gainPercent

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        return when (inputAudioFormat.encoding) {
            C.ENCODING_PCM_16BIT, C.ENCODING_PCM_FLOAT -> inputAudioFormat
            else -> AudioProcessor.AudioFormat.NOT_SET
        }
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return

        val inputSize = inputBuffer.remaining()
        val outputBuffer = replaceOutputBuffer(inputSize)
        val scale = gainScale

        if (scale == 1f) {
            outputBuffer.put(inputBuffer)
            outputBuffer.flip()
            return
        }

        when (inputAudioFormat.encoding) {
            C.ENCODING_PCM_16BIT -> processPcm16(inputBuffer, outputBuffer, scale)
            C.ENCODING_PCM_FLOAT -> processPcmFloat(inputBuffer, outputBuffer, scale)
            else -> outputBuffer.put(inputBuffer)
        }
        outputBuffer.flip()
    }

    private fun processPcm16(input: ByteBuffer, output: ByteBuffer, scale: Float) {
        input.order(ByteOrder.nativeOrder())
        output.order(ByteOrder.nativeOrder())
        while (input.remaining() >= 2) {
            val sample = input.short.toInt()
            val amplified = (sample * scale)
                .roundToInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            output.putShort(amplified.toShort())
        }
        if (input.hasRemaining()) output.put(input)
    }

    private fun processPcmFloat(input: ByteBuffer, output: ByteBuffer, scale: Float) {
        input.order(ByteOrder.nativeOrder())
        output.order(ByteOrder.nativeOrder())
        while (input.remaining() >= 4) {
            val sample = input.float
            output.putFloat((sample * scale).coerceIn(-1f, 1f))
        }
        if (input.hasRemaining()) output.put(input)
    }

    private fun percentToLinearScale(percent: Int): Float {
        if (percent <= 100) return 1f
        val ratio = percent / 100.0
        return ratio.toFloat()
    }
}
