"""
File management API endpoints.
"""
from typing import Optional
from difflib import SequenceMatcher
import re
from fastapi import APIRouter, Depends, HTTPException, Query
import secrets
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, delete, or_
from sqlalchemy.orm import selectinload

from ..database import get_db
from ..models import File, User, WatchProgress
from ..schemas import FileResponse, FileListResponse, FileUpdate, WatchProgressUpdate
from ..auth import get_current_user
from ..telegram import delete_from_storage_channel
from ..config import get_settings
from ..services import (
    escape_like, 
    sanitize_filename, 
    add_urls_to_file, 
    fetch_recent_files, 
    fetch_continue_watching_files
)

router = APIRouter(prefix="/files", tags=["Files"])
settings = get_settings()


@router.get("", response_model=FileListResponse)
async def list_files(
    folder_id: Optional[int] = Query(None, description="Filter by folder ID (null for root)"),
    file_type: Optional[str] = Query(None, description="Filter by file type"),
    search: Optional[str] = Query(None, description="Search by filename"),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List user's files with optional filtering."""
    query = select(File).where(File.user_id == current_user.id).options(selectinload(File.watch_progress))
    
    
    # Apply filters
    if folder_id is not None:
        query = query.where(File.folder_id == folder_id)
    elif not search and not file_type:
        # If simply browsing (no search/filter), only show files in root (folder_id is NULL)
        query = query.where(File.folder_id.is_(None))
        
    if file_type:
        query = query.where(File.file_type == file_type)
    if search:
        query = query.where(File.file_name.ilike(f"%{escape_like(search)}%", escape="\\"))
    
    # Get total count
    count_query = select(func.count()).select_from(query.subquery())
    total = (await db.execute(count_query)).scalar()
    
    # Apply pagination
    query = query.order_by(File.created_at.desc())
    query = query.offset((page - 1) * per_page).limit(per_page)
    
    result = await db.execute(query)
    files = result.scalars().all()
    
    return FileListResponse(
        files=[FileResponse(**add_urls_to_file(f)) for f in files],
        total=total,
        page=page,
        per_page=per_page,
    )


@router.get("/subtitles", response_model=FileListResponse)
async def get_subtitles(
    video_id: int = Query(..., description="Video file id used to rank matching subtitle names"),
    limit: int = Query(4, ge=1, le=4),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Return the latest subtitle files, ranked by similarity to the current video name.

    TelePlay stores a user's Telegram uploads in one storage channel, so the user's
    subtitle pool is the same chat visible to the player. We only expose the four
    most recently added subtitle files and sort those by filename similarity.
    """
    video_result = await db.execute(
        select(File).where(File.id == video_id, File.user_id == current_user.id)
    )
    video = video_result.scalar_one_or_none()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    subtitle_exts = (".srt", ".vtt", ".ass", ".ssa")
    filters = [File.file_name.ilike(f"%{ext}") for ext in subtitle_exts]

    result = await db.execute(
        select(File)
        .where(File.user_id == current_user.id, or_(*filters))
        .options(selectinload(File.watch_progress))
        .order_by(File.created_at.desc())
        .limit(4)
    )
    candidates = list(result.scalars().all())

    def normalize(name: str) -> str:
        base = re.sub(r"\.[^.]+$", "", name.lower())
        base = re.sub(r"[._\-]+", " ", base)
        base = re.sub(r"\[[^]]*]", " ", base)
        base = re.sub(r"\([^)]*\)", " ", base)
        base = re.sub(r"\b(2160p|1080p|720p|480p|4k|8k|webdl|webrip|bluray|brrip|x264|x265|h264|h265|hevc|aac|ddp|dts)\b", " ", base)
        return re.sub(r"\s+", " ", base).strip()

    video_name = normalize(video.file_name)

    ranked = sorted(
        candidates,
        key=lambda f: SequenceMatcher(None, video_name, normalize(f.file_name)).ratio(),
        reverse=True,
    )[:limit]

    return FileListResponse(
        files=[FileResponse(**add_urls_to_file(f)) for f in ranked],
        total=len(ranked),
        page=1,
        per_page=limit,
    )


@router.get("/recent", response_model=FileListResponse)
async def get_recent_files(
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get recently added files across all folders."""
    files = await fetch_recent_files(db, current_user.id, limit)
    
    return FileListResponse(
        files=[FileResponse(**add_urls_to_file(f)) for f in files],
        total=len(files),
        page=1,
        per_page=limit,
    )


@router.get("/continue-watching", response_model=FileListResponse)
async def get_continue_watching(
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get files with watch progress."""
    files = await fetch_continue_watching_files(db, current_user.id, limit)
    
    return FileListResponse(
        files=[FileResponse(**add_urls_to_file(f)) for f in files],
        total=len(files),
        page=1,
        per_page=limit,
    )


@router.get("/storage", response_model=dict)
async def get_storage_stats(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get total storage usage."""
    query = select(func.sum(File.file_size)).where(File.user_id == current_user.id)
    result = await db.execute(query)
    total_size = result.scalar() or 0
    
    return {
        "total_size": total_size,
        "limit": -1  # Unlimited
    }


@router.get("/{file_id}", response_model=FileResponse)
async def get_file(
    file_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get a specific file by ID."""
    result = await db.execute(
        select(File).where(File.id == file_id, File.user_id == current_user.id).options(selectinload(File.watch_progress))
    )
    file = result.scalar_one_or_none()
    
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(**add_urls_to_file(file))


@router.patch("/{file_id}", response_model=FileResponse)
async def update_file(
    file_id: int,
    update_data: FileUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Update file metadata (rename, move to folder)."""
    result = await db.execute(
        select(File).where(File.id == file_id, File.user_id == current_user.id)
    )
    file = result.scalar_one_or_none()
    
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    # Update fields
    if update_data.file_name is not None:
        file.file_name = sanitize_filename(update_data.file_name)
    if update_data.folder_id is not None:
        file.folder_id = update_data.folder_id if update_data.folder_id != 0 else None
    
    await db.commit()
    
    # Re-fetch with relationships
    result = await db.execute(
        select(File).where(File.id == file_id).options(selectinload(File.watch_progress))
    )
    file = result.scalar_one()
    
    return FileResponse(**add_urls_to_file(file))


@router.delete("/{file_id}")
async def delete_file(
    file_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Delete a file from database and Telegram channel."""
    result = await db.execute(
        select(File).where(File.id == file_id, File.user_id == current_user.id)
    )
    file = result.scalar_one_or_none()
    
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    # Delete from Telegram storage channel
    await delete_from_storage_channel(file.channel_message_id)
    
    # Delete from database
    await db.delete(file)
    await db.commit()
    
    return {"message": "File deleted successfully"}


@router.post("/batch-delete")
async def batch_delete_files(
    file_ids: list[int],
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Delete multiple files."""
    # Fetch all files
    result = await db.execute(
        select(File).where(File.id.in_(file_ids), File.user_id == current_user.id)
    )
    files = result.scalars().all()
    
    if not files:
        return {"message": "No files found to delete"}
    
    # Collect message IDs for Telegram deletion
    msg_ids = [f.channel_message_id for f in files]
    
    # Delete from Telegram (batch)
    if msg_ids:
        await delete_from_storage_channel(msg_ids)
    
    # Delete from DB
    for file in files:
        await db.delete(file)
        
    await db.commit()
    
    return {"message": f"Deleted {len(files)} files"}


@router.post("/{file_id}/progress")
@router.put("/{file_id}/progress")
async def update_progress(
    file_id: int,
    progress: WatchProgressUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Update watch progress. Supports both POST and PUT."""
    # Check file exists
    result = await db.execute(select(File).where(File.id == file_id, File.user_id == current_user.id))
    file = result.scalar_one_or_none()
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
        
    # Get or create progress
    result = await db.execute(
        select(WatchProgress).where(WatchProgress.file_id == file_id, WatchProgress.user_id == current_user.id)
    )
    watch_progress = result.scalar_one_or_none()
    
    if not watch_progress:
        watch_progress = WatchProgress(
            user_id=current_user.id,
            file_id=file_id,
            position=progress.position,
            duration=int(progress.duration) if progress.duration else None,
            completed=False
        )
        db.add(watch_progress)
    else:
        watch_progress.position = progress.position
        if progress.duration:
             watch_progress.duration = int(progress.duration)
        
    await db.commit()
    await db.refresh(watch_progress)
    return watch_progress


@router.get("/{file_id}/progress")
async def get_progress(
    file_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get watch progress for a file."""
    result = await db.execute(
        select(WatchProgress).where(
            WatchProgress.file_id == file_id, 
            WatchProgress.user_id == current_user.id
        )
    )
    progress = result.scalar_one_or_none()
    
    if not progress:
        return {"position": 0, "duration": 0, "completed": False}
    
    return {
        "position": progress.position,
        "duration": progress.duration or 0,
        "completed": progress.completed
    }


@router.post("/{file_id}/share", response_model=FileResponse)
async def share_file(
    file_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Generate a permanent public link for the file."""
    result = await db.execute(
        select(File).where(File.id == file_id, File.user_id == current_user.id).options(selectinload(File.watch_progress))
    )
    file = result.scalar_one_or_none()
    
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    # Generate hash if not exists or regenerate
    # Using 16 bytes = 32 hex chars
    file.public_hash = secrets.token_hex(16)
    
    await db.commit()
    
    # Re-fetch with relationships
    result = await db.execute(
        select(File).where(File.id == file_id).options(selectinload(File.watch_progress))
    )
    file = result.scalar_one()
    
    return FileResponse(**add_urls_to_file(file))


@router.delete("/{file_id}/share", response_model=FileResponse)
async def revoke_share(
    file_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Revoke the public link for the file."""
    result = await db.execute(
        select(File).where(File.id == file_id, File.user_id == current_user.id).options(selectinload(File.watch_progress))
    )
    file = result.scalar_one_or_none()
    
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    file.public_hash = None
    
    await db.commit()
    
    # Re-fetch with relationships
    result = await db.execute(
        select(File).where(File.id == file_id).options(selectinload(File.watch_progress))
    )
    file = result.scalar_one()
    
    return FileResponse(**add_urls_to_file(file))
@router.post("/batch-move")
async def batch_move_files(
    move_data: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Move multiple files to a folder."""
    file_ids = move_data.get("ids", [])
    folder_id = move_data.get("folder_id")
    
    if folder_id == 0:
        folder_id = None
        
    # Verify target folder belongs to user
    if folder_id is not None:
        from ..models import Folder
        folder_check = await db.execute(
            select(Folder).where(Folder.id == folder_id, Folder.user_id == current_user.id)
        )
        if not folder_check.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="Target folder not found")
            
    # Update files
    from sqlalchemy import update
    await db.execute(
        update(File)
        .where(File.id.in_(file_ids), File.user_id == current_user.id)
        .values(folder_id=folder_id)
    )
    
    await db.commit()
    return {"message": f"Moved {len(file_ids)} files"}
