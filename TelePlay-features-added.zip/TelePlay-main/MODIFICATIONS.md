# TelePlay feature changes

Implemented in this build:

1. **Add subtitle** in the player subtitle list
   - Added an `Add subtitle` action at the bottom of the subtitle tracks.
   - Shows the 4 newest subtitle files from the user's TelePlay Telegram storage, ranked by filename similarity to the current video.
   - Supports `.srt`, `.vtt`, `.ass`, `.ssa`.
   - Displays each subtitle filename and file size.
   - Added `Select from local storage` for local subtitle files.

2. **Sound Boost**
   - Added a 100%–300% playback-only sound boost slider.
   - Uses a Media3 PCM audio processor; the source media file is never re-encoded.
   - High boost levels can still clip already-full samples, so 100% is the original level.

3. **External Player**
   - Added `Open with external player` and an Android chooser so the user can select a compatible installed player.
   - Uses the app's public streaming URL so the external player does not need TelePlay's Authorization header.

4. **APK build workflow**
   - Added `.github/workflows/android-debug.yml` for a GitHub Actions `assembleDebug` build and APK artifact upload.
   - Bumped Android version to `1.0.2` / versionCode `7`.

## Build note

This environment cannot complete the Android build because the Gradle 8.5 distribution and Maven dependencies are not available locally and outbound network access is blocked. The modified source is ready to build in Android Studio or GitHub Actions.
